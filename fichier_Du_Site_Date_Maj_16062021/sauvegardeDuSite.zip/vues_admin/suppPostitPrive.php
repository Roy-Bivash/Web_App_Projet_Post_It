<div class="container">

    <h3 class="text-center bg-danger">Attention la suppression de tous les post-It Privé n'est pas recommendé et est irreversible !!</h3>
    <hr>
    <h4 class="text-center" style="color:red">Pensez à sauvegarder les données avant de procéder</h4>
    <br>
    <!-- Boutton suppression -->
    <div class="d-grid gap-2 col-6 mx-auto">
        <a href="../admin/action_suppPostitPrive.php" class="btn btn-danger" type="button">Supprimer definitivement les Post-it Privé</a>
    </div>


</div>